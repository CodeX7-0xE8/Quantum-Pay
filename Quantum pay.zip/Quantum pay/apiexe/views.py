from django.shortcuts import render

# Create your views here.
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json, random, time

@csrf_exempt
def register_stub(request):
    if request.method == "POST":
        body = {}
        try:
            body = json.loads(request.body.decode("utf-8") or "{}")
        except:
            pass
        return JsonResponse({
            "status": "success",
            "message": "User registered",
            "user": {"id": 1, "name": body.get("name","Test User"), "email": body.get("email","test@x.com")}
        })

@csrf_exempt
def pay_stub(request):
    if request.method == "POST":
        try:
            payload = json.loads(request.body.decode("utf-8") or "{}")
        except:
            return JsonResponse({"status": "fail", "error_code": "bad_json", "message": "Invalid JSON"}, status=400)

        amount = payload.get("amount")
        recipient = payload.get("recipient")

        if amount is None or amount <= 0:
            return JsonResponse({"status": "fail", "error_code": "invalid_amount", "message": "Amount must be positive"}, status=400)
        if not recipient:
            return JsonResponse({"status": "fail", "error_code": "missing_recipient", "message": "Recipient is required"}, status=400)

        # Simulate random failure
        success = random.random() > 0.15
        if success:
            return JsonResponse({
                "status": "success",
                "transactionId": int(random.random() * 1000000),
                "amount": amount,
                "message": "Payment processed"
            })
        else:
            # Example of failure reason
            fail_reason = random.choice([
                "Insufficient funds",
                "Network timeout",
                "Suspected fraud",
                "Payment gateway error"
            ])
            return JsonResponse({
                "status": "fail",
                "error_code": "payment_failed",
                "message": fail_reason
            }, status=400)

    return JsonResponse({"error": "POST only"}, status=400)

