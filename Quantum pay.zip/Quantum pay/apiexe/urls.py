from django.urls import path
from .views import register_stub, pay_stub

urlpatterns = [
    path('register/', register_stub),
    path('pay/', pay_stub),
]
